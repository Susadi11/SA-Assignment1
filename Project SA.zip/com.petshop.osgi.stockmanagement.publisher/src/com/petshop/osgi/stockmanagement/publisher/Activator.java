package com.petshop.osgi.stockmanagement.publisher;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

    private ServiceRegistration<?> serviceRegistration;
    
    @Override
    public void start(BundleContext context) throws Exception {
        System.out.println("\n\n▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓");
        System.out.println("▓                                                                           ▓");
        System.out.println("▓           \u001B[36mPET SHOP STOCK MANAGEMENT SERVICE PUBLISHER\u001B[0m                   ▓");
        System.out.println("▓                                                                           ▓");
        System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\n\n");
        
        // Create service implementation
        StockManagementService service = new StockManagementServiceImpl();
        
        // Register the service
        serviceRegistration = context.registerService(
                StockManagementService.class.getName(), service, null);
        
        System.out.println("\u001B[32m✓ Stock Management Service has been registered.\u001B[0m");
        
        // Add initial stock items for demonstration
        System.out.println("\n\u001B[33m>>> Initializing inventory with sample data...\u001B[0m");
        service.addItem("DF001", "Premium Dog Food", "Food", 45, 29.99);
        service.addItem("CL002", "Clumping Cat Litter", "Accessories", 30, 15.99);
        service.addItem("FT003", "10-Gallon Fish Tank", "Accessories", 5, 49.99);
        service.addItem("CB004", "Luxury Bird Cage", "Housing", 8, 89.99);
        service.addItem("DT005", "Durable Chew Toy", "Toys", 25, 12.50);
        service.addItem("CM006", "Cat Medicine", "Health", 7, 24.99);
        service.addItem("HF007", "Hamster Food", "Food", 20, 8.99);
        service.addItem("PS008", "Pet Shampoo", "Grooming", 15, 14.50);
        
        // Display the stock table
        System.out.println("\n\u001B[33m>>> Current Inventory:\u001B[0m");
        service.displayColorfulStockTable();
        
        // Display a random report
        System.out.println("\n\u001B[33m>>> Generated Stock Report:\u001B[0m");
        System.out.println(service.generateRandomStockReport());
        
        System.out.println("\n\u001B[32m✓ Stock Management Publisher initialization complete and ready for service!\u001B[0m");
    }

    @Override
    public void stop(BundleContext context) throws Exception {
        System.out.println("\n\u001B[33m>>> Stock Management Service Publisher stopping...\u001B[0m");
        
        if (serviceRegistration != null) {
            serviceRegistration.unregister();
            serviceRegistration = null;
            System.out.println("\u001B[31m✗ Stock Management Service has been unregistered.\u001B[0m");
        }
        
        System.out.println("\u001B[31m✗ Stock Management Service Publisher stopped.\u001B[0m");
    }
}